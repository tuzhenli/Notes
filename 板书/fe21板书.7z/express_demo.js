// express_demo.js 文件

// 引入 express 并且创建一个 express 实例赋值给 app
var express = require('express')
var express = require('express')
var bodyParser = require("body-parser")

var app = express()

// app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

var todoList = []

// 配置静态文件目录
app.use(express.static('static'))

var sendHtml = function(path, response) {
    var fs = require('fs')
    var options = {
        encoding: 'utf-8'
    }
    fs.readFile(path, options, function(err, data){
        console.log(`读取的html文件 ${path} 内容是`, data)
        response.send(data)
    })
}
// 用 get 定义一个给用户访问的网址
// request 是浏览器发送的请求
// response 是我们要发给浏览器的响应
app.get('/', function(request, response) {
    // var r = `
    // `
    // fs 是 file system 文件系统的缩写
    // fs 是 node 中处理文件和目录的库
    // var fs = require('fs')
    // var options = {
    //     encoding: 'utf-8'
    // }
    // fs.readFile('index.html', options, function(err, data){
    //     console.log('读取的html文件内容是', data)
    //     response.send(data)
    // })
    var path = 'index.html'
    sendHtml(path, response)
})

var todos = [
    {
        id: 1,
        task: '吃饭',
    }
]
// fs.writeFile
// fs.readFile

var addTodo = function(todo) {
    if (todos.length > 0) {
        // 如果有元素，那么新添加的元素的 id 就是最后一个元素的 id + 1
        todo.id = todos[todos.length-1].id + 1
    } else {
        // 第一个元素的 id 是 1
        todo.id = 1
    }
    todos.push(todo)
}

var todoById = function(id) {
    var index = -1
    for (var i = 0; i < todos.length; i++) {
        var t = todos[i]
        if (t.id == id) {
            index = i
            break
        }
    }
    // 判断是否找到了 id 为 id 的元素的下标
    if (index == -1) {
        return null
    } else {
        return t
    }
}
//
// d = {}
// d.deleteTodo = function() {
// }

var deleteTodo = function(id) {
    var t = todoById(id)
    // 判断是否找到了 id 为 id 的元素的下标
    var hasTodo = (t != null)
    if (hasTodo) {
        var index = -1
        for (var i = 0; i < todos.length; i++) {
            var t = todos[i]
            if (t.id == id) {
                index = i
                break
            }
        }
        // 删除这个元素 并且返回 true
        todos.splice(index, 1)
        // todos.removeIndex(index)
    }
    return hasTodo
}

var updateTodo = function(id, task) {
    var t = todoById(id)
    // 判断是否找到了 id 为 id 的元素的下标
    var hasTodo = (t != null)
    if (hasTodo) {
        // 更新这个元素 并且返回 true
        t.task = task
    }
    return hasTodo
}

app.get('/todo/all', function(request, response) {
    var r = JSON.stringify(todos)
    response.send(r)
})
/*
todo 后端程序提供了 4 个 API, 说明如下


1, 获得所有的 todo, 返回的是一个数组
GET
http://vip.cocode.cc:3000/todo/all
var r = {
    url: '/todo/all',
    type: 'get',
    success: function(data) {
        console.log(data)
    }
}
$.ajax(r)

2, 发送 JSON 格式字符串来创建一个 todo
要求设置 Content-Type 为 application/json
POST
{"task": "study"}
http://vip.cocode.cc:3000/todo/add
var todo = {
    "task": "study"
}
var r = {
    url: '/todo/add',
    type: 'post',
    contentType: 'application/json',
    data: JSON.stringify(todo),
    success: function(data) {
        console.log(data)
    }
}
$.ajax(r)

3, 发送 JSON 格式字符串来更新一个 todo
要求设置 Content-Type 为 application/json
POST
{"task": "study", "id": 1}
http://vip.cocode.cc:3000/todo/update
var todo = {
    "task": "updated todo",
    "id": 1,
}
var r = {
    url: '/todo/update',
    type: 'post',
    contentType: 'application/json',
    data: JSON.stringify(todo),
    success: function(data) {
        console.log(data)
    }
}
$.ajax(r)


4, 删除一个 todo
GET
http://vip.cocode.cc:3000/todo/delete?id=1

*/
app.post('/todo/add', function(request, response) {
    // request.body
    console.log('todo add body', request.body)
    var t = request.body
    addTodo(t)
    response.send(JSON.stringify(t))
})

app.post('/todo/update', function(request, response) {
    // request.body
    console.log('todo update body', request.body)
    var t = request.body
    updateTodo(t.id, t.task)
    response.send(JSON.stringify(t))
})

app.get('/todo/delete', function(request, response) {
    console.log('delete', request.query)
    var id = Number(request.query.id)
    deleteTodo(id)
    response.send(String(id))
})
/*
1

3
*/
// listen 函数的第一个参数是我们要监听的端口
// 这个端口是要浏览器输入的
// 默认的端口是 80
// 所以如果你监听 80 端口的话，浏览器就不需要输入端口了
// 但是 1024 以下的端口是系统保留端口，需要管理员权限才能使用
var server = app.listen(8081, function () {
  var host = server.address().address
  var port = server.address().port

  console.log("应用实例，访问地址为 http://%s:%s", host, port)
})
